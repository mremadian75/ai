Future Island Staging Browser Validation Evidence Pack
Generated at: 2026-06-14T14:01:14Z
Canonical path: approved worker/simulator/optional orchestrator -> signed WordPress REST callback -> validation -> canonical records.
n8n status: optional example only; evidence pack success does not require n8n assets.

Included files:
- MANIFEST.md
- fixtures/provider/aeo-missing-answer.json
- fixtures/provider/aeo-valid-gap.json
- fixtures/provider/creative-invalid-token-leak.json
- fixtures/provider/creative-valid-analysis.json
- fixtures/provider/social-invalid-private.json
- fixtures/provider/social-mixed-batch.json
- fixtures/provider/social-valid-topic.json
- integrations/examples/n8n/OPTIONAL_future-island-provider-callback-template.json
- integrations/examples/n8n/README_OPTIONAL_N8N_PROVIDER_CALLBACK.md
- logs/provider-fixture-trial.log
- logs/test-all-timeout-safe.log
- reports/COMMAND_ROOM_BROWSER_VALIDATION_GUIDE.md
- reports/OPERATOR_QA_BROWSER_PLAYBOOK.md
- reports/OPTIONAL_N8N_WORKFLOW_PACK_NOTES.md
- reports/ORCHESTRATOR_AGNOSTIC_CALLBACK_GUIDE.md
- reports/PILOT_READINESS_REPORT.md
- reports/PLUGIN_ACTIVATION_AND_MIGRATION_READINESS.md
- reports/PRIVATE_BETA_SECURITY_REVIEW_UPDATED.md
- reports/PROVIDER_FIXTURE_STAGING_TRIAL_REPORT.md
- reports/SIGNED_CALLBACK_SIMULATOR_BROWSER_TRIAL.md
- reports/STAGING_BROWSER_VALIDATION_SPRINT_REPORT.md
- reports/UI_IMPLEMENTATION_REPORT.md
- reports/WARNING_CLEANUP_REPORT.md
- ui-snippets/SCREENSHOTS_OR_HTML_SNIPPETS_BUNDLE.zip
- ui-snippets/ui-snippets/command-room.html
- ui-snippets/ui-snippets/decision-map.html
- ui-snippets/ui-snippets/decision-report.html
- ui-snippets/ui-snippets/onboarding.html
- ui-snippets/ui-snippets/operator-qa.html
- ui-snippets/ui-snippets/provider-ingestion-ledger.html
- ui-snippets/ui-snippets/run-timeline.html
- ui-snippets/ui-snippets/staging-browser-validation.html
